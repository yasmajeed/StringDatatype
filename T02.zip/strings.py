hero = "$$$Superman$$$"
print(hero)

# Now I will use the strip() function to remove all the $ symbols from the beginning and end 
print(hero.strip("$"))

