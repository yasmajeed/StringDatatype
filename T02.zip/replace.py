# Create variable called single_string with the sentence
single_string = "The!quick!brown!fox!jumps!over!the!lazy!dog!"

# Use the replace function to replace all the ! characters with a blank space
string_space = single_string.replace("!", " ")
print(string_space)

# Use the upper function 
string_upper = string_space.upper()
print(string_upper)

# now print the sentence in reverse using extended slice method
print(string_upper[::-1])

# I love coding :)